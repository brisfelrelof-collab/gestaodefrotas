# Gestão de Frota — React/TSX

Port completo do projecto original HTML/JS para **React 18 + TypeScript + Vite**.  
A arquitectura de ficheiros espelha 1:1 a estrutura original (`pap.zip`).

---

## Arquitectura de ficheiros

```
frota-react/
├── index.html                  ← entrada HTML (CDN: Chart.js, Leaflet, Bootstrap Icons)
├── vite.config.ts
├── package.json
├── tsconfig.json
│
└── src/
    ├── main.tsx                ← ponto de entrada React
    ├── App.tsx                 ← router SPA (substitui window.location.href)
    │
    ├── types/
    │   └── index.ts            ← interfaces TypeScript (Veiculo, Motorista, Rota, Aluguer, AppUser…)
    │
    ├── store/
    │   └── index.ts            ← espelho do no-firebase.js — CRUD localStorage + auth + validação placa
    │
    ├── styles/
    │   └── global.css          ← merge de login.css + dashboard.css + veiculos.css + … (todos os CSS originais)
    │
    ├── components/
    │   ├── Sidebar.tsx         ← sidebar com overlay mobile (espelho do HTML sidebar em todas as páginas)
    │   ├── PageHeader.tsx      ← header com título, data, menu btn, logout
    │   └── StatusBadge.tsx     ← StatusBadge + Modal reutilizável + LoadingRow + EmptyRow
    │
    ├── hooks/
    │   └── useAuth.ts          ← hook que lê o utilizador actual do localStorage
    │
    └── pages/
        ├── LoginPage.tsx       ← login.html + login.js + login.css
        ├── DashboardPage.tsx   ← dashboard.html + dashboard.js + Chart.js
        ├── VeiculosPage.tsx    ← veiculos.html + veiculos.js + validação placa angolana
        ├── MotoristasPage.tsx  ← motoristas.html + motoristas.js
        ├── RotasPage.tsx       ← rotas.html + rotas.js + exportar CSV
        ├── AlugueresPage.tsx   ← alugueres.html + alugueres.js + exportar CSV
        ├── MonitoramentoPage.tsx ← monitoramento.html + monitoramento.js + Leaflet map + ESP32 GPS
        └── UtilizadoresPage.tsx  ← utilizadores.html + utilizadores.js + gestão de utilizadores
```

---

## Correspondência com o projecto original

| Ficheiro original              | Equivalente React/TSX                          |
|--------------------------------|------------------------------------------------|
| `js/no-firebase.js`            | `src/store/index.ts`                           |
| `css/login.css`                | `src/styles/global.css` (secção Login)         |
| `css/dashboard.css`            | `src/styles/global.css` (secções Sidebar…)     |
| `css/veiculos.css` …           | `src/styles/global.css` (secções Table…)       |
| `pages/login.html`             | `src/pages/LoginPage.tsx`                      |
| `pages/dashboard.html`         | `src/pages/DashboardPage.tsx`                  |
| `pages/veiculos.html`          | `src/pages/VeiculosPage.tsx`                   |
| `pages/motoristas.html`        | `src/pages/MotoristasPage.tsx`                 |
| `pages/rotas.html`             | `src/pages/RotasPage.tsx`                      |
| `pages/alugueres.html`         | `src/pages/AlugueresPage.tsx`                  |
| `pages/monitoramento.html`     | `src/pages/MonitoramentoPage.tsx`              |
| `pages/utilizadores.html`      | `src/pages/UtilizadoresPage.tsx`               |
| `js/dashboard.js`              | lógica em `DashboardPage.tsx`                  |
| `js/veiculos.js`               | lógica em `VeiculosPage.tsx`                   |
| … etc.                         | …                                              |

---

## Instalar e executar

```bash
# 1. Entrar na pasta
cd frota-react

# 2. Instalar dependências
npm install

# 3. Iniciar servidor de desenvolvimento
npm run dev
# → http://localhost:5173

# 4. Build de produção
npm run build
npm run preview
```

---

## Credenciais de demonstração

| Email             | Senha |
|-------------------|-------|
| admin@gmail.com   | 1     |
| d@gmail.com       | 1     |

---

## Dependências externas (CDN — carregadas em `index.html`)

| Biblioteca       | Versão  | Uso                              |
|-----------------|---------|----------------------------------|
| Bootstrap Icons  | 1.11.3  | Todos os ícones `bi-*`           |
| Poppins (Google) | —       | Fonte principal                  |
| Chart.js         | latest  | Gráfico de actividade (Dashboard)|
| Leaflet          | 1.9.4   | Mapa GPS (Monitoramento)         |

Todas as outras dependências são zero — sem Redux, sem React Router, sem Axios.  
O estado é gerido com `useState`/`useEffect` e persistido em `localStorage`.
